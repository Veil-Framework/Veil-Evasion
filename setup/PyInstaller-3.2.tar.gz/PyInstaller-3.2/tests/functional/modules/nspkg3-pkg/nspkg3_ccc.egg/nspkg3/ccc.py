
print ('this is module %s' % __name__)
