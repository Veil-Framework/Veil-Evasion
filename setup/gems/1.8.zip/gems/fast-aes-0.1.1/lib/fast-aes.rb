# This file just bridges the loading of the fast_aes.c extension,
# with the FastAES include that can be used.
require 'fast_aes'
require 'fast_aes_static'