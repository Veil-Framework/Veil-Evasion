class FastAES
  module Static

    
    
    
  end
end